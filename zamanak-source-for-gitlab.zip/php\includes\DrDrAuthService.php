<?php

declare(strict_types=1);

final class DrDrAuthService
{
    public static function normalizeMobile(mixed $raw): ?string
    {
        if (!is_string($raw)) {
            return null;
        }

        $mobile = trim($raw);
        $mobile = str_replace([' ', '-', '(', ')'], '', $mobile);

        if (str_starts_with($mobile, '+98')) {
            $mobile = '0' . substr($mobile, 3);
        } elseif (str_starts_with($mobile, '98') && strlen($mobile) === 12) {
            $mobile = '0' . substr($mobile, 2);
        }

        if (!preg_match('/^09\d{9}$/', $mobile)) {
            return null;
        }

        return $mobile;
    }

    public static function normalizeOtpCode(mixed $raw): ?string
    {
        if (!is_string($raw) && !is_numeric($raw)) {
            return null;
        }

        $code = trim((string) $raw);
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $ascii = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        $code = str_replace($persian, $ascii, $code);
        $code = str_replace($arabic, $ascii, $code);
        $code = preg_replace('/\s+/', '', $code) ?? '';

        if (!preg_match('/^\d{4,8}$/', $code)) {
            return null;
        }

        return $code;
    }

    /**
     * @return array{ok: true, retry_after: int, deduped?: bool}
     */
    public static function sendOtp(string $doctorId, string $mobile): array
    {
        $doctorId = GoogleTokensRepository::normalizeUserId($doctorId);
        $config = self::apiConfig();

        if (!IntegrationRateLimiter::allow('drdr_send_otp_' . $doctorId, 5)) {
            throw new IntegrationException('rate_limited', 'تعداد درخواست کد زیاد است. چند دقیقه بعد دوباره تلاش کنید.');
        }

        return DrDrPendingLoginRepository::withDoctorLock($doctorId, function () use ($doctorId, $mobile, $config): array {
            $recent = DrDrPendingLoginRepository::recentSendForMobile($doctorId, $mobile);
            if ($recent !== null) {
                return [
                    'ok' => true,
                    'retry_after' => $recent['retry_after'],
                    'deduped' => true,
                ];
            }

            $cooldown = DrDrPendingLoginRepository::resendCooldownRemaining($doctorId, $mobile);
            if ($cooldown > 0) {
                throw new IntegrationException(
                    'otp_cooldown',
                    'کد قبلی هنوز معتبر است. ' . $cooldown . ' ثانیه صبر کنید و همان کد پیامکی را وارد کنید.'
                );
            }

            DrDrPendingLoginRepository::clear($doctorId);

            $response = HttpClient::request(
                'POST',
                $config['send_otp_url'],
                self::apiHeaders($config['api_client_id']),
                ['mobile' => $mobile],
                'json',
                DrDrPendingLoginRepository::cookiePathForDoctor($doctorId)
            );

            if ($response['status'] < 200 || $response['status'] >= 300 || !self::isSuccessfulDrDrBody($response['body'])) {
                ProviderIntegrationService::logIntegrationEvent($doctorId, 'drdr', false, 'send_otp_rejected');
                throw new IntegrationException('send_otp_failed', self::humanizeDrDrError($response['body'], 'ارسال کد تأیید DrDr ناموفق بود.'));
            }

            DrDrPendingLoginRepository::save($doctorId, $mobile, is_array($response['body']) ? $response['body'] : null);
            ProviderIntegrationService::logIntegrationEvent($doctorId, 'drdr', true, 'send_otp_success');

            return [
                'ok' => true,
                'retry_after' => DrDrPendingLoginRepository::RESEND_COOLDOWN_SECONDS,
            ];
        });
    }

    private static function isSuccessfulDrDrBody(?array $body): bool
    {
        if (!is_array($body)) {
            return false;
        }

        $payload = self::unwrapDrDrPayload($body);
        if (self::extractAccessToken($payload) !== null || self::findJwtTokenInBody($body) !== null) {
            return true;
        }

        if (($body['ok'] ?? null) === false) {
            return false;
        }

        return ($body['ok'] ?? null) === true;
    }

    private static function unwrapDrDrPayload(?array $body): ?array
    {
        if (!is_array($body)) {
            return null;
        }

        if (isset($body['result']) && is_array($body['result'])) {
            return $body['result'];
        }

        if (isset($body['payload']) && is_array($body['payload'])) {
            return $body['payload'];
        }

        if (isset($body['data']) && is_array($body['data'])) {
            return $body['data'];
        }

        return $body;
    }

    /**
     * @param array<string, mixed>|null $body
     * @return array{access_token: string, refresh_token: ?string, expires_at: ?int}
     */
    public static function extractTokensFromOAuthBody(?array $body): array
    {
        if (!is_array($body)) {
            throw new IntegrationException('invalid_token', 'پاسخ DrDr نامعتبر است.');
        }

        if (($body['ok'] ?? null) === false) {
            throw new IntegrationException(
                'verify_otp_failed',
                self::humanizeDrDrError($body, 'کد تأیید DrDr نامعتبر است یا منقضی شده.')
            );
        }

        foreach (['payload', 'result', 'data'] as $key) {
            $value = $body[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                $candidate = trim($value);
                if (str_contains($candidate, '.') || strlen($candidate) >= 20) {
                    return [
                        'access_token' => $candidate,
                        'refresh_token' => null,
                        'expires_at' => null,
                    ];
                }
            }
        }

        $payload = self::unwrapDrDrPayload($body);
        $accessToken = self::extractAccessToken($payload);
        if ($accessToken === null) {
            $accessToken = self::extractAccessToken($body);
        }

        if ($accessToken === null) {
            $accessToken = self::findJwtTokenInBody($body);
        }

        if ($accessToken === null && !self::isSuccessfulDrDrBody($body)) {
            throw new IntegrationException('invalid_token', 'توکن DrDr دریافت نشد.');
        }

        if ($accessToken === null) {
            $hint = self::extractDrDrErrorMessage($body);
            if ($hint !== '' && str_contains($hint, 'ارسال شد')) {
                throw new IntegrationException(
                    'verify_otp_failed',
                    'پاسخ DrDr مربوط به ارسال کد بود نه تأیید. دوباره «ارسال کد» بزنید و کد جدید را وارد کنید.'
                );
            }

            throw new IntegrationException('invalid_token', 'DrDr توکن دسترسی برنگرداند.');
        }

        $refreshToken = self::extractRefreshToken($payload) ?? self::extractRefreshToken($body);
        $expiresAt = self::extractExpiresAt($payload) ?? self::extractExpiresAt($body);

        return [
            'access_token' => $accessToken,
            'refresh_token' => $refreshToken,
            'expires_at' => $expiresAt,
        ];
    }

    /**
     * Store DrDr tokens obtained from browser-direct OAuth (same flow as drdr.ir login).
     *
     * @return array{ok: true, connected: true}
     */
    public static function storeClientTokens(
        string $doctorId,
        string $accessToken,
        ?string $refreshToken = null,
        ?int $expiresAt = null
    ): array {
        $doctorId = GoogleTokensRepository::normalizeUserId($doctorId);
        $accessToken = trim($accessToken);

        if ($accessToken === '') {
            throw new IntegrationException('invalid_token', 'توکن DrDr دریافت نشد.');
        }

        DoctorExternalConnectionsRepository::upsert(
            doctorId: $doctorId,
            provider: 'drdr',
            accessToken: $accessToken,
            refreshToken: $refreshToken,
            expiresAt: $expiresAt
        );

        DrDrPendingLoginRepository::clear($doctorId);
        ProviderIntegrationService::logIntegrationEvent($doctorId, 'drdr', true, 'verify_otp_success:client');

        return [
            'ok' => true,
            'connected' => true,
        ];
    }

    /**
     * @return array{
     *   client_id: string,
     *   client_secret: string,
     *   init_url: string,
     *   token_url: string,
     *   scope: string
     * }
     */
    public static function publicOtpClientConfig(): array
    {
        $config = self::apiConfig();

        return [
            'client_id' => $config['api_client_id'],
            'client_secret' => $config['api_client_secret'],
            'init_url' => $config['send_otp_url'],
            'token_url' => $config['oauth_token_url'],
            'scope' => $config['oauth_scope'] !== '' ? $config['oauth_scope'] : '*',
        ];
    }

    /**
     * @return array{ok: true, connected: true}
     */
    public static function verifyOtpAndStore(string $doctorId, string $mobile, string $code): array
    {
        $doctorId = GoogleTokensRepository::normalizeUserId($doctorId);

        if (DoctorExternalConnectionsRepository::isConnected($doctorId, 'drdr')) {
            return [
                'ok' => true,
                'connected' => true,
            ];
        }

        $code = self::normalizeOtpCode($code);
        if ($code === null) {
            throw new IntegrationException('invalid_code', 'کد تأیید نامعتبر است.');
        }

        if (!IntegrationRateLimiter::allow('drdr_verify_otp_' . $doctorId, 8)) {
            throw new IntegrationException('rate_limited', 'تعداد تلاش تأیید زیاد است. یک دقیقه صبر کنید.');
        }

        $pending = DrDrPendingLoginRepository::getActiveForDoctor($doctorId);
        if ($pending !== null) {
            $sentAt = (int) ($pending['sent_at'] ?? 0);
            $pendingFresh = $sentAt > 0 && (time() - $sentAt) <= DrDrPendingLoginRepository::VERIFY_MAX_AGE_SECONDS;
            $storedMobile = self::normalizeMobile($pending['mobile']);

            if ($pendingFresh && $storedMobile !== null) {
                if ($storedMobile !== $mobile) {
                    throw new IntegrationException(
                        'mobile_mismatch',
                        'شماره موبایل با کد ارسال‌شده مطابقت ندارد. همان شماره‌ای را وارد کنید که کد به آن پیامک شده.'
                    );
                }

                $mobile = $storedMobile;
            }
        }

        $config = self::apiConfig();
        $response = self::requestVerify($config, $doctorId, $mobile, $code);

        if ($response['status'] < 200 || $response['status'] >= 300) {
            ProviderIntegrationService::logIntegrationEvent(
                $doctorId,
                'drdr',
                false,
                'verify_otp_rejected:http' . $response['status'] . ':' . self::summarizeDrDrBody($response['body'])
            );
            throw new IntegrationException('verify_otp_failed', self::humanizeDrDrError($response['body'], 'کد تأیید DrDr نامعتبر است یا منقضی شده.'));
        }

        try {
            $tokens = self::extractTokensFromOAuthBody(is_array($response['body']) ? $response['body'] : null);
        } catch (IntegrationException $e) {
            ProviderIntegrationService::logIntegrationEvent(
                $doctorId,
                'drdr',
                false,
                'verify_otp_rejected:body:' . self::summarizeDrDrBody($response['body'])
            );
            throw $e;
        }

        DoctorExternalConnectionsRepository::upsert(
            doctorId: $doctorId,
            provider: 'drdr',
            accessToken: $tokens['access_token'],
            refreshToken: $tokens['refresh_token'],
            expiresAt: $tokens['expires_at']
        );

        DrDrPendingLoginRepository::clear($doctorId);
        ProviderIntegrationService::logIntegrationEvent($doctorId, 'drdr', true, 'verify_otp_success');

        return [
            'ok' => true,
            'connected' => true,
        ];
    }

    /**
     * @return array{
     *   api_client_id: string,
     *   api_client_secret: string,
     *   send_otp_url: string,
     *   oauth_token_url: string,
     *   oauth_scope: string
     * }
     */
    private static function apiConfig(): array
    {
        $path = __DIR__ . '/../config/providers/drdr.php';
        $file = is_file($path) ? require $path : [];
        if (!is_array($file)) {
            $file = [];
        }

        return [
            'api_client_id' => trim((string) ($file['api_client_id'] ?? 'f60d5037-b7ac-404a-9e3a-a263fd9f8054')),
            'api_client_secret' => trim((string) ($file['api_client_secret'] ?? 'vZHXE1Wx15g0RMVacaTN4KbKJ1mCk3jjkx3ZoKDj')),
            'send_otp_url' => trim((string) ($file['send_otp_url'] ?? 'https://drdr.ir/api/v3/auth/login/mobile/init')),
            'oauth_token_url' => trim((string) ($file['oauth_token_url'] ?? 'https://drdr.ir/api/v3/oauth/token/')),
            'oauth_scope' => trim((string) ($file['oauth_scope'] ?? '*')),
        ];
    }

    /**
     * @return array<string, string>
     */
    private static function apiHeaders(string $clientId): array
    {
        return [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json, text/plain, */*',
            'Cache-Control' => 'no-cache',
            'Pragma' => 'no-cache',
            'User-Agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1',
            'client-id' => $clientId,
            'Origin' => 'https://drdr.ir',
            'Referer' => 'https://drdr.ir/',
        ];
    }

    /**
     * @param array<string, mixed>|null $body
     */
    private static function humanizeDrDrError(?array $body, string $fallback): string
    {
        if (!is_array($body)) {
            return $fallback;
        }

        foreach (['message', 'error', 'detail'] as $key) {
            $value = $body[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return self::translateDrDrError(trim($value));
            }
        }

        if (isset($body['meta']['message']['body']) && is_string($body['meta']['message']['body'])) {
            return self::translateDrDrError(trim($body['meta']['message']['body']));
        }

        if (isset($body['data']) && is_array($body['data'])) {
            return self::humanizeDrDrError($body['data'], $fallback);
        }

        return $fallback;
    }

    private static function translateDrDrError(string $message): string
    {
        $normalized = strtolower($message);

        if (str_contains($normalized, 'user credentials were incorrect')) {
            return 'کد تأیید DrDr اشتباه است.';
        }

        if (str_contains($normalized, 'client authentication failed')) {
            return 'پیکربندی اتصال DrDr روی سرور نامعتبر است. با پشتیبانی تماس بگیرید.';
        }

        if (str_contains($normalized, 'too many attempts')) {
            return 'تعداد تلاش زیاد است. چند دقیقه بعد دوباره امتحان کنید.';
        }

        if (str_contains($normalized, 'تعداد درخواست') || str_contains($normalized, 'too many')) {
            return 'درخواست زیاد بود. چند دقیقه بعد دوباره تلاش کنید.';
        }

        if (str_contains($message, 'خطایی در سیستم') || str_contains($message, 'مشکلی در سیستم') || str_contains($normalized, 'system error')) {
            return 'کد پیامکی منقضی یا نامعتبر است. دوباره «ارسال کد» بزنید، کد جدید را وارد کنید و تا پایان شمارشگر «ارسال مجدد» نزنید.';
        }

        return $message;
    }

    /**
     * @param array<string, mixed>|null $body
     */
    private static function isDrDrSystemError(?array $body): bool
    {
        if (!is_array($body)) {
            return false;
        }

        $raw = self::extractDrDrErrorMessage($body);

        return str_contains($raw, 'خطایی در سیستم')
            || str_contains($raw, 'مشکلی در سیستم')
            || str_contains(strtolower($raw), 'system error');
    }

    /**
     * @param array<string, mixed> $body
     */
    private static function extractDrDrErrorMessage(array $body): string
    {
        if (isset($body['meta']['message']['body']) && is_string($body['meta']['message']['body'])) {
            return trim($body['meta']['message']['body']);
        }

        foreach (['message', 'error', 'detail'] as $key) {
            $value = $body[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        if (isset($body['data']) && is_array($body['data'])) {
            return self::extractDrDrErrorMessage($body['data']);
        }

        return '';
    }

    /**
     * @param array<string, mixed>|null $body
     */
    private static function summarizeDrDrBody(?array $body): string
    {
        if (!is_array($body)) {
            return 'empty';
        }

        $message = '';
        if (isset($body['meta']['message']['body']) && is_string($body['meta']['message']['body'])) {
            $message = trim($body['meta']['message']['body']);
        }

        if ($message === '') {
            foreach (['message', 'error', 'detail'] as $key) {
                $value = $body[$key] ?? null;
                if (is_string($value) && trim($value) !== '') {
                    $message = trim($value);
                    break;
                }
            }
        }

        if ($message === '') {
            return 'ok=' . json_encode($body['ok'] ?? null);
        }

        $message = preg_replace('/\s+/', ' ', $message) ?? $message;

        return mb_substr($message, 0, 120);
    }

    /**
     * @param array<string, mixed>|null $body
     */
    private static function extractAccessToken(?array $body): ?string
    {
        if (!is_array($body)) {
            return null;
        }

        foreach (['access_token', 'accessToken', 'token'] as $key) {
            $value = $body[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        if (isset($body['user']) && is_array($body['user'])) {
            foreach (['token', 'access_token', 'accessToken'] as $key) {
                $value = $body['user'][$key] ?? null;
                if (is_string($value) && trim($value) !== '') {
                    return trim($value);
                }
            }
        }

        foreach (['result', 'payload', 'data'] as $wrapper) {
            $value = $body[$wrapper] ?? null;
            if (!is_string($value)) {
                continue;
            }

            $trimmed = trim($value);
            if ($trimmed !== '' && (str_contains($trimmed, '.') || strlen($trimmed) >= 20)) {
                return $trimmed;
            }
        }

        if (isset($body['payload']) && is_array($body['payload'])) {
            return self::extractAccessToken($body['payload']);
        }

        if (isset($body['result']) && is_array($body['result'])) {
            return self::extractAccessToken($body['result']);
        }

        if (isset($body['meta']) && is_array($body['meta'])) {
            return self::extractAccessToken($body['meta']);
        }

        if (isset($body['data']) && is_array($body['data'])) {
            return self::extractAccessToken($body['data']);
        }

        return null;
    }

    /**
     * DrDr stores a JWT in `token` (see drdr.ir localStorage user.state.token).
     *
     * @param array<string, mixed>|null $body
     */
    private static function findJwtTokenInBody(?array $body): ?string
    {
        if (!is_array($body)) {
            return null;
        }

        $walker = static function (mixed $node) use (&$walker): ?string {
            if (is_string($node)) {
                $trimmed = trim($node);
                if (str_starts_with($trimmed, 'eyJ') && substr_count($trimmed, '.') >= 2) {
                    return $trimmed;
                }

                return null;
            }

            if (!is_array($node)) {
                return null;
            }

            foreach (['token', 'access_token', 'accessToken'] as $key) {
                $value = $node[$key] ?? null;
                if (is_string($value)) {
                    $trimmed = trim($value);
                    if (str_starts_with($trimmed, 'eyJ') && substr_count($trimmed, '.') >= 2) {
                        return $trimmed;
                    }
                }
            }

            foreach ($node as $value) {
                $found = $walker($value);
                if ($found !== null) {
                    return $found;
                }
            }

            return null;
        };

        return $walker($body);
    }

    /**
     * @param array<string, mixed>|null $body
     */
    private static function extractRefreshToken(?array $body): ?string
    {
        if (!is_array($body)) {
            return null;
        }

        foreach (['refresh_token', 'refreshToken'] as $key) {
            $value = $body[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        if (isset($body['payload']) && is_array($body['payload'])) {
            return self::extractRefreshToken($body['payload']);
        }

        if (isset($body['data']) && is_array($body['data'])) {
            return self::extractRefreshToken($body['data']);
        }

        return null;
    }

    /**
     * @param array<string, mixed>|null $body
     */
    private static function extractExpiresAt(?array $body): ?int
    {
        if (!is_array($body)) {
            return null;
        }

        $expiresIn = $body['expires_in'] ?? $body['expiresIn'] ?? null;
        if (is_numeric($expiresIn)) {
            return time() + max(0, (int) $expiresIn);
        }

        if (isset($body['payload']) && is_array($body['payload'])) {
            return self::extractExpiresAt($body['payload']);
        }

        if (isset($body['data']) && is_array($body['data'])) {
            return self::extractExpiresAt($body['data']);
        }

        return null;
    }

    /**
     * @param array{
     *   api_client_id: string,
     *   api_client_secret: string,
     *   oauth_token_url: string,
     *   oauth_scope: string
     * } $config
     * @return array{status: int, body: ?array<string, mixed>, raw: string}
     */
    private static function requestVerify(array $config, string $doctorId, string $mobile, string $code): array
    {
        $payload = [
            'grant_type' => 'otp',
            'client_id' => $config['api_client_id'],
            'client_secret' => $config['api_client_secret'],
            'mobile' => $mobile,
            'otp_code' => $code,
            'scope' => $config['oauth_scope'] !== '' ? $config['oauth_scope'] : '*',
        ];

        return HttpClient::request(
            'POST',
            $config['oauth_token_url'],
            self::apiHeaders($config['api_client_id']),
            $payload,
            'json',
            DrDrPendingLoginRepository::cookiePathForDoctor($doctorId)
        );
    }
}
